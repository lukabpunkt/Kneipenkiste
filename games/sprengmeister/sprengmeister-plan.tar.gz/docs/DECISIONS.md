# Entscheidungen (ADR-Log)

Format: **ADR-{n} · {Datum} · {Titel}** — Kontext · Entscheidung · Konsequenz (max. 5 Zeilen).

## ADR-1 · 2026-09-04 · Gleicher Stack wie Drinkshot/Tresor, Module per Kopie
Kontext: Drei Spiele, eine Familie. Entscheidung: Vite/TS/PixiJS/GSAP; Module kopieren, Shared-Package erst nach v1.0 aller drei. Konsequenz: Keine Monorepo-Komplexität jetzt.

## ADR-2 · 2026-09-04 · Eigene Mine wird stumm als leeres Feld aufgedeckt
Kontext: Der Kern des Pitches sind "sichere Trittsteine". Würde die eigene Mine sichtbar, wäre der Vorteil weg. Entscheidung: Identischer Code-Pfad zu leerem Feld, `publicView` erzwingt Ununterscheidbarkeit, Test. Konsequenz: Information bleibt asymmetrisch; Beobachten des Grabverhaltens wird zum Meta-Spiel.

## ADR-3 · 2026-09-04 · Temperatur-Hinweise statt Distanzzahlen
Kontext: Exakte Zahlen finden die Kiste in 2 Zügen. Entscheidung: Drei Stufen (Chebyshev 1 / 2 / ≥3). Konsequenz: 4–8 Grabungen pro Runde; Balancing über `rules.ts`.

## ADR-4 · 2026-09-04 · Kiste darf auf verminter Zelle liegen
Kontext: Die letzte Grabung soll nie sicher sein. Entscheidung: Kiste uniform über alle Zellen, "Preis der Gier" als eigenes Ergebnis. Konsequenz: Seltener Doppelmoment, eigene Sequenz.

## ADR-5 · 2026-09-04 · Tokens statt Sofort-Verteilen
Kontext: Verteilen mitten in der Grabphase bricht den Fluss und erfordert Handy-Übergabe. Entscheidung: Trinken sofort, Verteilen gesammelt am Rundenende. Konsequenz: Eigener Distribute-Screen mit Iteration.

## ADR-6 · 2026-09-04 · BoardView als wiederverwendbare PIXI-Komponente mit Modi
Kontext: Das Feld wird in Place, Dig und Result gebraucht und ist interaktiv. Entscheidung: Ein Canvas, Modus-Umschaltung, Canvas wird zwischen Screen-Hosts umgehängt. Konsequenz: Keine Neuinitialisierung, konsistenter Look, ein Hit-Testing-Pfad.
